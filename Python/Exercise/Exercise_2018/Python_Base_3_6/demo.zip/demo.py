# python demo.py 12 demo, asd
# ['demo.py', '12', 'demo,', 'asd']
import sys
print('type(sys.argv), sys.argv', type(sys.argv), sys.argv)
