import React, { Component } from 'react'
import ReactDOM from 'react-dom'

import BindEvent from '@/components/BindEvent'


ReactDOM.render(<div>
    <BindEvent></BindEvent>
</div>, document.querySelector('#app'))