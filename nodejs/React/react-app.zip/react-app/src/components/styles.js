export default {
    itemStyle: { border: "1px dashed #ccc", margin: '10px', padding: '5px', boxShadow: "0 0 5px #ccc" },
    userStyle: { fontSize: "14px" },
    contentStyle: { fontSize: "12px" },
}