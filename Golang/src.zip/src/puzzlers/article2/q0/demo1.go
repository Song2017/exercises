package main

import "fmt"

func main() {
	fmt.Println("Hello, world!")
}
