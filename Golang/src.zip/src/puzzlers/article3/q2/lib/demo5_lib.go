package lib5

import "fmt"

func Hello(name string) {
	fmt.Printf("Hello, %s!\n", name)
}
